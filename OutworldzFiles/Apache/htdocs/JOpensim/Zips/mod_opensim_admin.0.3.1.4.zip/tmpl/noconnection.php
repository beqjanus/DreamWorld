<?php
/**
* @version $Id: mod_jdownloads_admin_stats.php v3.2
* @package mod_jdownloads_admin_stats
* @copyright (C) 2016 Arno Betz
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* @author Arno Betz http://www.jDownloads.com
*/

defined( '_JEXEC' ) or die( 'Restricted access' );

echo JText::_('MOD_JOPENSIM_ADMIN_ERROR_NOCONNECTION');
?>

